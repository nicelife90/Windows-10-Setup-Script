﻿# Turn off hibernate
# Отключить режим гибернации
POWERCFG /HIBERNATE OFF