﻿# Allow an app through Controlled folder access
# Разрешить работу приложения через контролируемый доступ к папкам
Start-Process -FilePath windowsdefender: