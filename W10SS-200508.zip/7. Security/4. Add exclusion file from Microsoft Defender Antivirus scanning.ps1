﻿# Add exclusion file from Microsoft Defender Antivirus scanning
# Добавить файл в список исключений сканирования Microsoft Defender
Start-Process -FilePath windowsdefender: