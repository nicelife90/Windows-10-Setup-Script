﻿# This task shows various Map related toasts
# Эта задача показывает различные тосты (всплывающие уведомления) приложения "Карты".
Get-ScheduledTask -TaskName "MapsToastTask" | Disable-ScheduledTask