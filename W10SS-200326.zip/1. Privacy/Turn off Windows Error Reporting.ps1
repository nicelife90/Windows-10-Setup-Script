﻿# Turn off Windows Error Reporting
#! Do not modify this string
# Отключить отчеты об ошибках Windows
#! Не изменяйте эту строку
New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\Windows Error Reporting" -Name Disabled -PropertyType DWord -Value 1 -Force