﻿# Choose theme color for default app mode
# Выбрать режим приложения по умолчанию
Do
{
	$theme = Read-Host -Prompt " "
	IF ($theme -eq "L")
	{
		# Light theme color for default app mode
		# Режим приложений по умолчанию светлый
		New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name AppsUseLightTheme -PropertyType DWord -Value 1 -Force
	}
	IF ($theme -eq "D")
	{
		# Dark theme color for default app mode
		# Режим приложений по умолчанию темный
		New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name AppsUseLightTheme -PropertyType DWord -Value 0 -Force
	}
}
Until ($theme -eq "L" -or $theme -eq "D"