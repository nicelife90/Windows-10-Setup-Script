﻿# Do not show "Windows Ink Workspace" button in taskbar
#! Do not modify this string
# Не показывать кнопку Windows Ink Workspace на панели задач
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\PenWorkspace -Name PenWorkspaceButtonDesiredVisibility -PropertyType DWord -Value 0 -Force