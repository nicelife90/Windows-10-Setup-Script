﻿# Turn off check boxes to select items
#! Do not modify this string
# Отключить флажки для выбора элементов
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name AutoCheckSelect -PropertyType DWord -Value 0 -Force