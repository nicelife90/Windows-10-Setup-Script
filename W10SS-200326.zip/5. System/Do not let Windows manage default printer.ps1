﻿# Do not let Windows manage default printer
# Windows set your default printer to be the one you used most recently at your current location
# Не разрешать Windows управлять принтером, используемым по умолчанию
# Windows настроивает в качестве используемого по умолчанию принтера тот принтер, который последним использовался в текущем местоположении
New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Windows" -Name LegacyDefaultPrinterMode -PropertyType DWord -Value 1 -Force