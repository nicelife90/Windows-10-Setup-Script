﻿# Delete temporary files that apps aren't using
#! Do not modify this string
# Удалять временные файлы, не используемые в приложениях
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy -Name 04 -PropertyType DWord -Value 1 -Force