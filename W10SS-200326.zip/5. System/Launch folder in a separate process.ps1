﻿# Launch folder in a separate process
#! Do not modify this string
# Запускать окна с папками в отдельном процессе
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name SeparateProcess -PropertyType DWord -Value 1 -Force