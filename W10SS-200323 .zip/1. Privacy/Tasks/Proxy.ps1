﻿# This task collects and uploads autochk SQM data if opted-in to the Microsoft Customer Experience Improvement Program
# Эта задача собирает и загружает данные SQM при участии в программе улучшения качества программного обеспечения
Get-ScheduledTask -TaskName "Proxy" | Disable-ScheduledTask