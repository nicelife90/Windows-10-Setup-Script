﻿# HelloFace
# HelloFace
Get-ScheduledTask -TaskName "FODCleanupTask" | Disable-ScheduledTask