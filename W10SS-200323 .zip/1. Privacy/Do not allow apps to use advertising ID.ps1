﻿# Do not allow apps to use advertising ID
#! Do not modify this string
# Не разрешать приложениям использовать идентификатор рекламы
#! Не изменяйте эту строку
New-ItemProperty -Path HKLM:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo -Name Enabled -PropertyType DWord -Value 0 -Force