﻿# Let Windows try to fix apps so they're not blurry
#! Do not modify this string
# Разрешить Windows исправлять размытость в приложениях
#! Не изменяйте эту строку
New-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name EnablePerProcessSystemDPI -PropertyType DWord -Value 1 -Force