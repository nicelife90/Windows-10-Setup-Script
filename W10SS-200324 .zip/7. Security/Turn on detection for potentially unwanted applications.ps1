﻿# Turn on detection for potentially unwanted applications
# Potentially unwanted applications (PUA) are not considered viruses, malware, or other types of threats, but they might perform actions on endpoints which adversely affect endpoint performance or use
# Включить обнаружение потенциально нежелательных приложений
# Потенциально нежелательные приложения не рассматриваются как вирусы, вредоносные программы или другие типы угроз, но они могут выполнять действия с ПК, которые негативно влияют на его производительность или использование
Set-MpPreference -PUAProtection Enabled