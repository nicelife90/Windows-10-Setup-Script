﻿# Turn on events auditing generated when a process is created or starts
# The OS generates audit events when a process is created (starts) and it's command line arguments (4688 event)
# Включить аудит событий, возникающих при создании или запуске процесса
# ОС записывает события аудита при создании (запуске) процесса и его аргумента командной строки
IF ($RU)
{
	auditpol /set /subcategory:"Создание процесса" /success:enable /failure:enable
}
else
{
	auditpol /set /subcategory:"Process Creation" /success:enable /failure:enable
}
New-ItemProperty -Path HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\Audit -Name ProcessCreationIncludeCmdLine_Enabled -PropertyType DWord -Value 1 -Force