﻿# Remove Microsoft Edge shortcut from the Desktop
#! Do not modify this string
# Удалить ярлык Microsoft Edge с рабочего стола
#! Не изменяйте эту строку
$value = Get-ItemPropertyValue -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" -Name Desktop
Remove-Item -Path "$value\Microsoft Edge.lnk" -Force -ErrorAction Ignore