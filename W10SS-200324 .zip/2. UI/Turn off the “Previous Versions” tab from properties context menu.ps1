﻿# Remove the "Previous Versions" tab from properties context menu
#! Do not modify this string
# Отключить отображение вкладки "Предыдущие версии" в свойствах файлов и папок
#! Не изменяйте эту строку
New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer -Name NoPreviousVersionsPage -PropertyType DWord -Value 1 -Force