﻿# Turn off Admin Approval Mode for administrators
#! Do not modify this string
# Отключить использование режима одобрения администратором для встроенной учетной записи администратора
#! Не изменяйте эту строку
New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System -Name ConsentPromptBehaviorAdmin -PropertyType DWord -Value 0 -Force