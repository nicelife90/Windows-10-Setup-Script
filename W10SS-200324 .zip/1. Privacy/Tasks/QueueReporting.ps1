﻿# Windows Error Reporting task to process queued reports
# Задача отчетов об ошибках обрабатывает очередь отчетов
Get-ScheduledTask -TaskName "QueueReporting" | Disable-ScheduledTask