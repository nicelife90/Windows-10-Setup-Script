﻿# Do not let websites provide locally relevant content by accessing language list
#! Do not modify this string
# Не позволять веб-сайтам предоставлять местную информацию за счет доступа к списку языков
#! Не изменяйте эту строку
New-ItemProperty -Path "HKCU:\Control Panel\International\User Profile" -Name HttpAcceptLanguageOptOut -PropertyType DWord -Value 1 -Force