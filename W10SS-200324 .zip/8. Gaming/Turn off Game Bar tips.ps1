﻿# Turn off Xbox Game Bar tips
# These tips are to learn more about using Xbox Game bar each time you open a game or app
# Отключить советы Xbox Game Bar
# Эти подсказки позволяют узнать больше об использовании Xbox Game Bar при каждом запуске игры или приложения
New-ItemProperty -Path HKCU:\Software\Microsoft\GameBar -Name ShowStartupPanel -PropertyType DWord -Value 0 -Force