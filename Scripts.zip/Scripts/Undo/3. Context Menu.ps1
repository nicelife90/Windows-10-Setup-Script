﻿# Добавить пункт "Извлечь" в контекстное меню Windows Installer (.msi)
# Тумблер находится слева
Если отсутствует Registry::HKEY_CLASSES_ROOT\Msi.Package\shell\Extract
{
	"Scripts\3. Context Menu\1. Add the Extract item to Windows Installer (.msi) context menu.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
Если присутсвует Registry::HKEY_CLASSES_ROOT\Msi.Package\shell\Extract
{
	"Scripts\3. Context Menu\1. Add the Extract item to Windows Installer (.msi) context menu.ps1" -Off
}

# Добавить пункт "Установить" в контекстное меню .cab архивов
# Тумблер находится слева
Если отсутствует Registry::HKEY_CLASSES_ROOT\CABFolder\Shell\RunAs\Command
{
	"Scripts\3. Context Menu\2. Add the Install item to the .cab archives context menu.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
Если присутсвует Registry::HKEY_CLASSES_ROOT\CABFolder\Shell\RunAs\Command
{
	"Scripts\3. Context Menu\2. Add the Install item to the .cab archives context menu.ps1" -Off
}

# Добавить "Запуск от имени другого пользователя" в контекстное меню .exe файлов
# Тумблер находится слева
Если присутсвует Registry::HKEY_CLASSES_ROOT\exefile\shell\runasuser -Name Extended
{
	"Scripts\3. Context Menu\3. Add the Run as different user item to the .exe files types context menu.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
Если отсутствует Registry::HKEY_CLASSES_ROOT\exefile\shell\runasuser -Name Extended
{
	"Scripts\3. Context Menu\3. Add the Run as different user item to the .exe files types context menu.ps1" -Off
}

# Скрыть пункт "Передать на устройство" из контекстного меню
# Тумблер находится слева
Если отсутствует "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked" -Name "{7AD84985-87B4-4a16-BE58-8B72A5B390F7}"))
{
	"Scripts\3. Context Menu\4. Hide the Cast to Device item from the context menu.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если присутсвует "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked" -Name "{7AD84985-87B4-4a16-BE58-8B72A5B390F7}")
{
	"Scripts\3. Context Menu\4. Hide the Cast to Device item from the context menu.ps1" -On
}

# Скрыть пункт "Отправить" (поделиться) из контекстного меню
# Тумблер находится слева
Если отсутствует "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked" -Name "{E2BF9676-5F8F-435C-97EB-11607A5BEDF7}"))
{
	"Scripts\3. Context Menu\5. Hide the Share item from the context menu.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если присутсвует "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked" -Name "{E2BF9676-5F8F-435C-97EB-11607A5BEDF7}")
{
	"Scripts\3. Context Menu\5. Hide the Share item from the context menu.ps1" -On
}

# Скрыть пункт "Изменить с помощью Paint 3D" из контекстного меню ###
# Тумблер находится слева
$extension = @(".bmp", ".gif", ".jpe", ".jpeg", ".jpg", ".png", ".tif", ".tiff")
Если отсутствуют "Registry::HKEY_CLASSES_ROOT\SystemFileAssociations\$extension\Shell\3D Edit"
{
	"Scripts\3. Context Menu\6. Hide the Edit with Paint 3D item from the context menu.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
$extension = @(".bmp", ".gif", ".jpe", ".jpeg", ".jpg", ".png", ".tif", ".tiff")
Если отсутствуют "Registry::HKEY_CLASSES_ROOT\SystemFileAssociations\$extension\Shell\3D Edit"
{
	"Scripts\3. Context Menu\6. Hide the Edit with Paint 3D item from the context menu.ps1" -On
}

# Скрыть пунк "Изменить с помощью приложения "Фотографии"" из контекстного меню
# Тумблер находится слева
if (Get-AppxPackage -Name Microsoft.Windows.Photos)
{
	Если отсутствует Registry::HKEY_CLASSES_ROOT\AppX43hnxtbyyps62jhe9sqpdzxn1790zetc\Shell\ShellEdit -Name ProgrammaticAccessOnly
	{
		"Scripts\3. Context Menu\7. Hide the Edit with Photos item from the context menu.ps1" -Off
	}
}
# Вернуть по умолчанию
# Тумблер находится справа
Если присутсвует Registry::HKEY_CLASSES_ROOT\AppX43hnxtbyyps62jhe9sqpdzxn1790zetc\Shell\ShellEdit -Name ProgrammaticAccessOnly
{
	"Scripts\3. Context Menu\7. Hide the Edit with Photos item from the context menu.ps1" -On
}

# Скрыть пункт "Создать новое видео" из контекстного меню
# Тумблер находится слева
if (Get-AppxPackage -Name Microsoft.Windows.Photos)
{
	Если отсутствует Registry::HKEY_CLASSES_ROOT\AppX43hnxtbyyps62jhe9sqpdzxn1790zetc\Shell\ShellCreateVideo -Name ProgrammaticAccessOnly
	{
		"Scripts\3. Context Menu\8. Hide the Create a new video item from the context menu.ps1" -Off
	}
}
# Вернуть по умолчанию
# Тумблер находится справа
Если присутсвует Registry::HKEY_CLASSES_ROOT\AppX43hnxtbyyps62jhe9sqpdzxn1790zetc\Shell\ShellCreateVideo -Name ProgrammaticAccessOnly
{
	"Scripts\3. Context Menu\8. Hide the Create a new video item from the context menu.ps1" -On
}

# Скрыть пункт "Изменить" из контекстного меню изображений
# Тумблер находится слева
if ((Get-WindowsCapability -Online -Name "Microsoft.Windows.MSPaint*").State -eq "Installed")
{
	Если отсутствует Registry::HKEY_CLASSES_ROOT\SystemFileAssociations\image\shell\edit -Name ProgrammaticAccessOnly
	{
		"Scripts\3. Context Menu\9 Hide the Edit item from the images context menu.ps1" -Off
	}
}
# Вернуть по умолчанию
# Тумблер находится справа
Если присутствует Registry::HKEY_CLASSES_ROOT\SystemFileAssociations\image\shell\edit -Name ProgrammaticAccessOnly
{
	"Scripts\3. Context Menu\9. Hide the Edit item from the images context menu.ps1" -On
}

# Скрыть пункт "Печать" из контекстного меню .bat и .cmd файлов
# Тумблер находится слева
Если отсутствуют Registry::HKEY_CLASSES_ROOT\batfile\shell\print -Name ProgrammaticAccessOnly
И
Registry::HKEY_CLASSES_ROOT\cmdfile\shell\print -Name ProgrammaticAccessOnly
{
	"Scripts\3. Context Menu\10. Hide the Print item from the .bat and .cmd context menu.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если присутствуют Registry::HKEY_CLASSES_ROOT\batfile\shell\print -Name ProgrammaticAccessOnly
И
Registry::HKEY_CLASSES_ROOT\cmdfile\shell\print -Name ProgrammaticAccessOnly
{
	"Scripts\3. Context Menu\10. Hide the Print item from the .bat and .cmd context menu.ps1" -On
}

# Скрыть пункт "Добавить в библиотеку" из контекстного меню
# Тумблер находится слева
Если значение "Registry::HKEY_CLASSES_ROOT\Folder\shellex\ContextMenuHandlers\Library Location" -Name "(Default)" равно "{3dad6c5d-2167-4cae-9914-f99e41c12cfa}"
{
	"Scripts\3. Context Menu\11. Hide the Include in Library item from the context menu.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение "Registry::HKEY_CLASSES_ROOT\Folder\shellex\ContextMenuHandlers\Library Location" -Name "(Default)" равно "-{3dad6c5d-2167-4cae-9914-f99e41c12cfa}"
{
	"Scripts\3. Context Menu\11. Hide the Include in Library item from the context menu.ps1" -On
}

# Скрыть пункт "Отправить" из контекстного меню папок
# Тумблер находится слева
Если значение Registry::HKEY_CLASSES_ROOT\AllFilesystemObjects\shellex\ContextMenuHandlers\SendTo -Name "(Default)" равно "{7BA4C740-9E81-11CF-99D3-00AA004AE837}"
{
	"Scripts\3. Context Menu\12. Hide the Include in Library item from the context menu.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение Registry::HKEY_CLASSES_ROOT\AllFilesystemObjects\shellex\ContextMenuHandlers\SendTo -Name "(Default)" равно "-{7BA4C740-9E81-11CF-99D3-00AA004AE837}"
{
	"Scripts\3. Context Menu\12. Hide the Include in Library item from the context menu.ps1" -On
}

# Скрыть пункт "Включить BitLocker" из контекстного меню
# Тумблер находится слева
Если издания Windows 10 Professional ИЛИ Enterprise
{
	Если отсутствуют:
	Registry::HKEY_CLASSES_ROOT\Drive\shell\encrypt-bde -Name ProgrammaticAccessOnly
	Registry::HKEY_CLASSES_ROOT\Drive\shell\encrypt-bde-elev -Name ProgrammaticAccessOnly
	Registry::HKEY_CLASSES_ROOT\Drive\shell\manage-bde -Name ProgrammaticAccessOnly
	Registry::HKEY_CLASSES_ROOT\Drive\shell\resume-bde -Name ProgrammaticAccessOnly
	Registry::HKEY_CLASSES_ROOT\Drive\shell\resume-bde-elev -Name ProgrammaticAccessOnly
	Registry::HKEY_CLASSES_ROOT\Drive\shell\unlock-bde -Name ProgrammaticAccessOnly
	{
		"Scripts\3. Context Menu\13. Hide the Turn on BitLocker item from the context menu.ps1" -Off
	}
}
# Вернуть по умолчанию
# Тумблер находится справа
Если издания Windows 10 Professional ИЛИ Enterprise
{
	Если присутствуют:
	Registry::HKEY_CLASSES_ROOT\Drive\shell\encrypt-bde -Name ProgrammaticAccessOnly
	Registry::HKEY_CLASSES_ROOT\Drive\shell\encrypt-bde-elev -Name ProgrammaticAccessOnly
	Registry::HKEY_CLASSES_ROOT\Drive\shell\manage-bde -Name ProgrammaticAccessOnly
	Registry::HKEY_CLASSES_ROOT\Drive\shell\resume-bde -Name ProgrammaticAccessOnly
	Registry::HKEY_CLASSES_ROOT\Drive\shell\resume-bde-elev -Name ProgrammaticAccessOnly
	Registry::HKEY_CLASSES_ROOT\Drive\shell\unlock-bde -Name ProgrammaticAccessOnly
	{
		"Scripts\3. Context Menu\13. Hide the Turn on BitLocker item from the context menu.ps1" -On
	}
}

# Удалить пункт "Точечный рисунок" из контекстного меню "Создать"
# Тумблер находится слева
if ((Get-WindowsCapability -Online -Name "Microsoft.Windows.MSPaint*").State -eq "Installed")
{
	Если присутствует Registry::HKEY_CLASSES_ROOT\.bmp\ShellNew -Name ItemName
	{
		"Scripts\3. Context Menu\14. Remove the Bitmap image item from the New context menu.ps1" -Off
	}
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-WindowsCapability -Online -Name "Microsoft.Windows.MSPaint*").State -eq "Installed")
{
	Если отсутствует Registry::HKEY_CLASSES_ROOT\.bmp\ShellNew
	{
		"Scripts\3. Context Menu\14. Remove the Bitmap image item from the New context menu.ps1" -On
	}
}

# Удалить пункт "Документ в формате RTF" из контекстного меню "Создать"
# Тумблер находится слева
if ((Get-WindowsCapability -Online -Name "Microsoft.Windows.WordPad*").State -eq "Installed")
{
	Если присутствует Registry::HKEY_CLASSES_ROOT\.rtf\ShellNew -Name ItemName
	{
		"Scripts\3. Context Menu\15. Remove the Rich Text Document item from the New context menu.ps1" -Off
	}
}
# Вернуть по умолчанию
# Тумблер находится справа
Если отсутствует Registry::HKEY_CLASSES_ROOT\.rtf\ShellNew
{
	"Scripts\3. Context Menu\15. Remove the Rich Text Document item from the New context menu.ps1" -On
}

# Удалить пункт "Сжатая ZIP-папка" из контекстного меню "Создать"
# Тумблер находится слева
Если присутствует Registry::HKEY_CLASSES_ROOT\.zip\CompressedFolder\ShellNew -Name ItemName
{
	"Scripts\3. Context Menu\16. Remove the Compressed (zipped) Folder item from the New context menu.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если отсутствует Registry::HKEY_CLASSES_ROOT\.zip\CompressedFolder\ShellNew
{
	"Scripts\3. Context Menu\16. Remove the Compressed (zipped) Folder item from the New context menu.ps1" -On
}

# Сделать доступными элементы контекстного меню "Открыть", "Изменить" и "Печать" при выделении более 15 элементов
# Тумблер находится слева
Если отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name MultipleInvokePromptMinimum
{
	"Scripts\3. Context Menu\17. Make the Open, Print, Edit context menu items available, when more than 15 items selected.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
Если присутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name MultipleInvokePromptMinimum
{
	"Scripts\3. Context Menu\17. Make the Open, Print, Edit context menu items available, when more than 15 items selected.ps1" -Off
}

# Скрыть пункт "Поиск приложения в Microsoft Store" в диалоге "Открыть с помощью"
# Тумблер находится слева
Если отсутствует HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer -Name NoUseStoreOpenWith
{
	"Scripts\3. Context Menu\18. Hide the Look for an app in the Microsoft Store item in Open with dialog.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если присутствует HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer -Name NoUseStoreOpenWith
{
	"Scripts\3. Context Menu\18. Hide the Look for an app in the Microsoft Store item in Open with dialog.ps1" -On
}

# Скрыть вкладку "Предыдущие версии" в свойствах файлов и папок и пункт контекстного меню "Восстановить прежнюю версию"
# Тумблер находится слева
Если отсутствует HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer -Name NoPreviousVersionsPage
{
	"Scripts\3. Context Menu\19. Hide the Previous Versions tab from files and folders context menu and Restore previous versions context menu item.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если присутствует HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer -Name NoPreviousVersionsPage
{
	"Scripts\3. Context Menu\19. Hide the Previous Versions tab from files and folders context menu and Restore previous versions context menu item.ps1" -On
}