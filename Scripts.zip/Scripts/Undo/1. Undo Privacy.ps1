﻿# Отключить службу "Функциональные возможности для подключенных пользователей и телеметрия"
# Тумблер находится слева
Если служба "DiagTrack" запущена ИЛИ имеет автоматический запуск
{
	"Scripts\1. Privacy\1. Turn off Connected User Experiences and Telemetry service.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если служба "DiagTrack" не запущена ИЛИ имеет не автоматический запуск
{
	"Scripts\1. Privacy\1. Turn off Connected User Experiences and Telemetry service.ps1" -On
}

# Отключить cлужбы для отдельных пользователей
# Тумблер находится слева
$services = @(
	"PimIndexMaintenanceSvc_*"
	"UnistoreSvc_*"
	"UserDataSvc_*"
)
Если службы запущены И значения (HKLM:\System\CurrentControlSet\Services\$services -Name Start) НЕ равны 4
{
	"Scripts\1. Privacy\2. Turn off per-user services.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа. Требуется перезагрузка
$services = @(
	"PimIndexMaintenanceSvc_*"
	"UnistoreSvc_*"
	"UserDataSvc_*"
)
Если службы НЕ запущены И значения (HKLM:\System\CurrentControlSet\Services\$services -Name Start) равны 4
{
	"Scripts\1. Privacy\2. Turn off per-user services.ps1" -On
}

Если издания Windows 10 "Enterprise" ИЛИ "Education"
{
	# Тумблер находится слева
	Если значение HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection -Name AllowTelemetry НЕ равно 0
	{
		"Scripts\1. Privacy\3. Set the operating system diagnostic data level.ps1" -Enterprise
	}
	# Вернуть по умолчанию. Если любые другие редакции
	# Тумблер находится справа
	Если значение HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection -Name AllowTelemetry равно 0
	{
		"Scripts\1. Privacy\3. Set the operating system diagnostic data level.ps1" -On
	}
}
Если издания Windows 10 НЕ "Enterprise" ИЛИ НЕ "Education"
{
	# Тумблер находится слева
	Если значение HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection -Name AllowTelemetry НЕ равно 1
	{
		"Scripts\1. Privacy\3. Set the operating system diagnostic data level.ps1" -NotEnterprise
	}
	# Вернуть по умолчанию. Если любые другие редакции
	# Тумблер находится справа
	Если значение HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection -Name AllowTelemetry равно 1
	{
		"Scripts\1. Privacy\3. Set the operating system diagnostic data level.ps1" -On
	}
}

# Отключить отчеты об ошибках Windows
# Тумблер находится слева
Если значение "HKCU:\Software\Microsoft\Windows\Windows Error Reporting" -Name Disabled НЕ равно 1
ИЛИ
отсутствует ("HKCU:\Software\Microsoft\Windows\Windows Error Reporting")
{
	"Scripts\1. Privacy\4. Turn off Windows Error Reporting.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение "HKCU:\Software\Microsoft\Windows\Windows Error Reporting" -Name Disabled равно 1
{
	"Scripts\1. Privacy\4. Turn off Windows Error Reporting.ps1" -On
}

# Изменить частоту формирования отзывов на "Никогда"
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Siuf\Rules -Name NumberOfSIUFInPeriod НЕ равно 0
ИЛИ
отсутствует (HKCU:\Software\Microsoft\Siuf\Rules -Name NumberOfSIUFInPeriod)
{
	"Scripts\1. Privacy\5. Change Windows Feedback frequency to Never.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Siuf\Rules -Name NumberOfSIUFInPeriod равно 1
{
	"Scripts\1. Privacy\5. Change Windows Feedback frequency to Never.ps1" -On
}

# Отключить задачи диагностического отслеживания
$tasks = @(
	"ProgramDataUpdater"
	"Microsoft Compatibility Appraiser"
	"Microsoft-Windows-DiskDiagnosticDataCollector"
	"TempSignedLicenseExchange"
	"MapsToastTask"
	"DmClient"
	"FODCleanupTask"
	"DmClientOnScenarioDownload"
	"BgTaskRegistrationMaintenanceTask"
	"File History (maintenance mode)"
	"WinSAT"
	"UsbCeip"
	"Consolidator"
	"Proxy"
	"MNO Metadata Parser"
	"NetworkStateChangeTask"
	"GatherNetworkInfo"
	"XblGameSaveTask"
	"EnableLicenseAcquisition"
	"QueueReporting"
	"FamilySafetyMonitor"
	"FamilySafetyRefreshTask"
)
# Если устройство не является ноутбуком
if ((Get-CimInstance -ClassName Win32_ComputerSystem).PCSystemType -ne 2)
{
	# HelloFace
	$tasks += "FODCleanupTask"
}
foreach ($task in $tasks)
{
	# Тумблер находится слева
	Если значение у состояния задачи "Ready"
	{
		"Scripts\1. Privacy\6. Turn off diagnostics tracking scheduled tasks.ps1" -Off
	}
}
foreach ($task in $tasks)
{
	# Вернуть по умолчанию
	# Тумблер находится справа
	Если значение у состояния задачи "Disabled"
	{
		"Scripts\1. Privacy\6. Turn off diagnostics tracking scheduled tasks.ps1" -On
	}
}

# Не использовать данные для входа для автоматического завершения настройки устройства и открытия приложений после перезапуска или обновления
# Тумблер находится слева
$SID = (Get-CimInstance -ClassName Win32_UserAccount | Where-Object -FilterScript {$_.Name -eq $env:USERNAME}).SID
Если значение "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\UserARSO\$SID" -Name OptOut НЕ равно 1
ИЛИ
отсутствует "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\UserARSO\$sid" -Name OptOut
{
	"Scripts\1. Privacy\7. Do not use sign-in info to automatically finish setting up device and reopen apps after an update or restart.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
$SID = (Get-CimInstance -ClassName Win32_UserAccount | Where-Object -FilterScript {$_.Name -eq $env:USERNAME}).SID
Если значение "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\UserARSO\$SID" -Name OptOut равно 1
{
	"Scripts\1. Privacy\7. Do not use sign-in info to automatically finish setting up device and reopen apps after an update or restart.ps1" -On
}

# Не позволять веб-сайтам предоставлять местную информацию за счет доступа к списку языков
# Тумблер находится слева
Если значение "HKCU:\Control Panel\International\User Profile" -Name HttpAcceptLanguageOptOut НЕ равно 1
ИЛИ
отсутствует "HKCU:\Control Panel\International\User Profile" -Name HttpAcceptLanguageOptOut
{
	"Scripts\1. Privacy\8. Do not let websites provide locally relevant content by accessing language list.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение "HKCU:\Control Panel\International\User Profile" -Name HttpAcceptLanguageOptOut равно 1
{
	"Scripts\1. Privacy\8. Do not let websites provide locally relevant content by accessing language list.ps1" -On
}

# НЕ разрешать приложениям использовать идентификатор рекламы
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo -Name Enabled НЕ равно 0
{
	"Scripts\1. Privacy\9. Do not allow apps to use advertising ID.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo -Name Enabled равно 0
{
	"Scripts\1. Privacy\9. Do not allow apps to use advertising ID.ps1" -On
}

# НЕ разрешать приложениям на других устройствах запускать приложения и отправлять сообщения на этом устройстве и наоборот
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\CDP -Name RomeSdkChannelUserAuthzPolicy НЕ равно 0
{
	"Scripts\1. Privacy\10. Do not let apps on other devices open and message apps on this device, and vice versa.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\CDP -Name RomeSdkChannelUserAuthzPolicy равно 0
{
	"Scripts\1. Privacy\10. Do not let apps on other devices open and message apps on this device, and vice versa.ps1" -On
}

# Не показывать экран приветствия Windows после обновлений и иногда при входе, чтобы сообщить о новых функциях и предложениях
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SubscribedContent-310093Enabled НЕ равно 0
ИЛИ
отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SubscribedContent-310093Enabled
{
	"Scripts\1. Privacy\11. Do not show the Windows welcome experiences after updates.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SubscribedContent-310093Enabled равно 0
{
	"Scripts\1. Privacy\11. Do not show the Windows welcome experiences after updates.ps1" -On
}

# Не показывать рекомендуемое содержимое в приложении "Параметры"
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SubscribedContent-338393Enabled НЕ равно 0
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SubscribedContent-353694Enabled НЕ равно 0
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SubscribedContent-353696Enabled НЕ равно 0
ИЛИ отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SubscribedContent-338393Enabled
ИЛИ отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SubscribedContent-353694Enabled
ИЛИ отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SubscribedContent-353696Enabled
{
	"Scripts\1. Privacy\12. Do not show suggested content in the Settings app.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SubscribedContent-338393Enabled равно 0
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SubscribedContent-353694Enabled равно 0
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SubscribedContent-353696Enabled равно 0
{
		"Scripts\1. Privacy\12. Do not show suggested content in the Settings app.ps1" -On
}

# Отключить автоматическую установку рекомендованных приложений
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SilentInstalledAppsEnabled НЕ равно 0
{
	"Scripts\1. Privacy\13. Turn off automatic installing suggested apps.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SilentInstalledAppsEnabled равно 0
{
	"Scripts\1. Privacy\13. Turn off automatic installing suggested apps.ps1" -On
}

# Не предлагать способы завершения настройки устройства для максимально эффективного использования Windows
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement -Name ScoobeSystemSettingEnabled НЕ равно 0
ИЛИ
отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement -Name ScoobeSystemSettingEnabled
{
	"Scripts\1. Privacy\14. Do not suggest ways I can finish setting up my device to get the most out of Windows.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement -Name ScoobeSystemSettingEnabled равно 0
{
	"Scripts\1. Privacy\14. Do not suggest ways I can finish setting up my device to get the most out of Windows.ps1" -On
}

# Не предлагать персонализированные возможности, основанные на выбранном параметре диагностических данных
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy -Name TailoredExperiencesWithDiagnosticDataEnabled равно 1
{
	"Scripts\1. Privacy\15. Do not offer tailored experiences based on the diagnostic data setting.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy -Name TailoredExperiencesWithDiagnosticDataEnabled не равно 1
{
	"Scripts\1. Privacy\15. Do not offer tailored experiences based on the diagnostic data setting.ps1" -On
}