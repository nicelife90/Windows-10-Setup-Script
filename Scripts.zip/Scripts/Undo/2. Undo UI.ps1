﻿# Отобразить "Этот компьютер" на рабочем столе
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel -Name "{20D04FE0-3AEA-1069-A2D8-08002B30309D}" НЕ равно 0
ИЛИ
отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel -Name "{20D04FE0-3AEA-1069-A2D8-08002B30309D}"
{
	"Scripts\2. UI\1. Show This PC on Desktop.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel -Name "{20D04FE0-3AEA-1069-A2D8-08002B30309D}" равно 1
{
	"Scripts\2. UI\1. Show This PC on Desktop.ps1" -Off
}

# Не использовать флажки для выбора элементов
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name AutoCheckSelect НЕ равно 0
{
	"Scripts\2. UI\2. Do not use check boxes to select items.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name AutoCheckSelect равно 0
{
	"Scripts\2. UI\2. Do not use check boxes to select items.ps1" -On
}

# Показывать скрытые файлы, папки и диски
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name Hidden НЕ равно 1
{
	"Scripts\2. UI\3. Show hidden files, folders, and drives.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name Hidden равно 1
{
	"Scripts\2. UI\3. Show hidden files, folders, and drives.ps1" -Off
}

# Показывать расширения для зарегистрированных типов файлов
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name HideFileExt НЕ равно 0
{
	"Scripts\2. UI\4. Show file name extensions.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name HideFileExt равно 0
{
	"Scripts\2. UI\4. Show file name extensions.ps1" -Off
}

# Не скрывать конфликт слияния папок
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name HideMergeConflicts НЕ равно 0
ИЛИ
отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name HideMergeConflicts
{
	"Scripts\Scripts\2. UI\5. 5. Do not hide folder merge conflicts.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name HideMergeConflicts ранво 0
{
	"Scripts\Scripts\2. UI\5. Show folder merge conflicts.ps1" -Off
}

# Открывать проводник для: "Этот компьютер"
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name LaunchTo НЕ равно 1
ИЛИ
отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name LaunchTo
{
	"Scripts\2. UI\6. Open File Explorer to This PC.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name LaunchTo равно 1
{
	"Scripts\2. UI\6. Open File Explorer to This PC.ps1" -Off
}

# Не отображать все папки в области навигации
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name NavPaneShowAllFolders НЕ равно 0
ИЛИ
отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name NavPaneShowAllFolders
{
	"Scripts\2. UI\7. Do not show all folders in the navigation pane.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name NavPaneShowAllFolders равно 0
{
	"Scripts\2. UI\7. Do not show all folders in the navigation pane.ps1" -On
}

# Не показывать кнопку Кортаны на панели задач
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name ShowCortanaButton НЕ равно 0
{
	"Scripts\2. UI\8. Do not show Cortana button on taskbar.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name ShowCortanaButton равно 0
{
	"Scripts\2. UI\8. Do not show Cortana button on taskbar.ps1" -On
}

# Не показывать уведомления поставщика синхронизации в проводнике
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name ShowSyncProviderNotifications НЕ равно 0
ИЛИ
отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name ShowSyncProviderNotifications
{
	"Scripts\2. UI\9. Do not show sync provider notification within File Explorer.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name ShowSyncProviderNotifications) -eq 0)
{
	"Scripts\2. UI\9. Do not show sync provider notification within File Explorer.ps1" -On
}

# Не показывать кнопку Просмотра задач
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name ShowTaskViewButton НЕ равно 0
ИЛИ
отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name ShowTaskViewButton
{
	"Scripts\2. UI\10. Do not show Task View button on taskbar.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name ShowTaskViewButton равно 0
{
	"Scripts\2. UI\10. Do not show Task View button on taskbar.ps1" -On
}

# Не показывать панель "Люди" на панели задач
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People -Name PeopleBand НЕ равно 0
ИЛИ
отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People -Name PeopleBand
{
	"Scripts\2. UI\11. Do not show People button on the taskbar.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People -Name PeopleBand равно 0
{
	"Scripts\2. UI\11. Do not show People button on the taskbar.ps1" -On
}

# Отображать секунды в системных часах на панели задач
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People -Name ShowSecondsInSystemClock НЕ равно 1
ИЛИ
отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People -Name ShowSecondsInSystemClock
{
	"Scripts\2. UI\12. Show seconds on taskbar clock.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People -Name ShowSecondsInSystemClock равно 1
{
	"Scripts\2. UI\12. Show seconds on taskbar clock.ps1" -Off
}

# Увеличить прозрачность панели задач
# Тумблер находится слева
Если значение HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name UseOLEDTaskbarTransparency НЕ равно 1
ИЛИ
отсутствует HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name UseOLEDTaskbarTransparency
{
	"Scripts\2. UI\13. Increase taskbar transparency.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name UseOLEDTaskbarTransparency равно 1
{
	"Scripts\2. UI\13. Increase taskbar transparency.ps1" -Off
}

# Не показывать при прикреплении окна, что можно прикрепить рядом с ним
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name SnapAssist НЕ равно 1
ИЛИ
отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name SnapAssist
{
	"Scripts\2. UI\14. Do not show when snapping a window, what can be attached next to it.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name SnapAssist равно 1
{
	"Scripts\2. UI\14. Do not show when snapping a window, what can be attached next to it.ps1" -On
}

# Развернуть диалог переноса файлов
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\OperationStatusManager -Name EnthusiastMode НЕ равно 1
ИЛИ
отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\OperationStatusManager -Name EnthusiastMode
{
	"Scripts\2. UI\15. Show more details in file transfer dialog.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\OperationStatusManager -Name EnthusiastMode равно 1
{
	"Scripts\2. UI\15. Show more details in file transfer dialog.ps1" -Off
}

# Отображать ленту проводника в развернутом виде
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Ribbon -Name MinimizedStateTabletModeOff НЕ равно 1
ИЛИ
отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Ribbon -Name MinimizedStateTabletModeOff
{
	"Scripts\2. UI\16. Show the Ribbon expanded in File Explorer.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Ribbon -Name MinimizedStateTabletModeOff равно 1
{
	"Scripts\2. UI\16. Show the Ribbon expanded in File Explorer.ps1" -On
}

# Запрашивать подтверждение на удаление файлов в корзину
# Тумблер находится слева
$ShellState = Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name ShellState
if ($ShellState[4] -eq 51)
{
	"Scripts\2. UI\17. Display recycle bin files delete confirmation.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
$ShellState = Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name ShellState
if ($ShellState[4] -ne 51)
{
	"Scripts\2. UI\17. Display recycle bin files delete confirmation.ps1" -Off
}

# Скрыть папку "Объемные объекты" из "Этот компьютер" и из панели быстрого доступа
# Тумблер находится слева
Если значение "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\FolderDescriptions\{31C0DD25-9439-4F12-BF41-7FF4EDA38722}\PropertyBag" -Name ThisPCPolicy НЕ равно "Hide"
ИЛИ
отсутствует "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\FolderDescriptions\{31C0DD25-9439-4F12-BF41-7FF4EDA38722}\PropertyBag" -Name ThisPCPolicy
{
	"Scripts\2. UI\18. Hide 3D Objects folder from This PC and from Quick Access Toolbar.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\FolderDescriptions\{31C0DD25-9439-4F12-BF41-7FF4EDA38722}\PropertyBag" -Name ThisPCPolicy равно "Hide"
{
	"Scripts\2. UI\18. Hide 3D Objects folder from This PC and from Quick Access Toolbar.ps1" -On
}

# Не показывать недавно используемые папки на панели быстрого доступа
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name ShowFrequent НЕ равно 0
ИЛИ
отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name ShowFrequent
{
	"Scripts\2. UI\19. Do not show Frequent folders in Quick access.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name ShowFrequent равно 0
{
	"Scripts\2. UI\19. Do not show Frequent folders in Quick access.ps1" -On
}

# Не показывать недавно использовавшиеся файлы на панели быстрого доступа
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name ShowRecent НЕ равно 0
ИЛИ
отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name ShowRecent
{
	"Scripts\2. UI\20. Do not show Recent files in Quick access.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name ShowRecent равно 0
{
	"Scripts\2. UI\20. Do not show Recent files in Quick access.ps1" -On
}

# Скрыть поле или значок поиска на панели задач
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Search -Name SearchboxTaskbarMode НЕ равно 0
ИЛИ
отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\Search -Name SearchboxTaskbarMode
{
	"Scripts\2. UI\21. Hide search box or search icon on taskbar.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Search -Name SearchboxTaskbarMode равно 0
{
	"Scripts\2. UI\21. Hide search box or search icon on taskbar.ps1" -On
}

# Не показывать кнопку Windows Ink Workspace на панели задач
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\PenWorkspace -Name PenWorkspaceButtonDesiredVisibility НЕ равно 0
ИЛИ
отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\PenWorkspace -Name PenWorkspaceButtonDesiredVisibility
{
	"Scripts\2. UI\22. Do not show Windows Ink Workspace button in taskbar.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\PenWorkspace -Name PenWorkspaceButtonDesiredVisibilityравно 0
{
	"Scripts\2. UI\22. Do not show Windows Ink Workspace button in taskbar.ps1" -On
}

# Всегда отображать все значки в области уведомлений
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name EnableAutoTray НЕ равно 0
ИЛИ
отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name EnableAutoTray
{
	"Scripts\2. UI\23. Always show all icons in the notification area.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name EnableAutoTray) -eq 0)
{
	"Scripts\2. UI\23. Always show all icons in the notification area.ps1" -On
}

# Установить крупные значки в Панели управления
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel -Name AllItemsIconView НЕ равно 0
ИЛИ отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel -Name AllItemsIconView
И
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel -Name StartupPage НЕ равно 1
ИЛИ отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel -Name StartupPage
{
	"Scripts\2. UI\24. Set the large icons in the Control Panel.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel -Name AllItemsIconView) -eq 0))
И
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel -Name StartupPage равно 1
{
	"Scripts\2. UI\24. Set the large icons in the Control Panel.ps1" -Off
}

# Установить режим Windows по умолчанию темный
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name SystemUsesLightTheme НЕ равно 1
{
	"Scripts\2. UI\25. Set theme color for default Windows mode.ps1" -Light
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name SystemUsesLightTheme равно 1
{
	"Scripts\2. UI\25. Set theme color for default Windows mode.ps1" -Dark
}

# Установить режим приложений по умолчанию светлый
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name AppsUseLightTheme НЕ равно 1
{
	"Scripts\2. UI\26. Set theme color for default app mode.ps1" -Light
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name AppsUseLightTheme равно 1
{
	"Scripts\2. UI\26. Set theme color for default app mode.ps1" -Dark
}

# Отображать цвет элементов в меню "Пуск", на панели задач и в центре уведомлений
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name SystemUsesLightTheme НЕ равно 1
{
	Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name ColorPrevalence НЕ равно 1
	{
		"Scripts\2. UI\27. Show accent color on Start, taskbar, and action center.ps1" -On
	}
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name SystemUsesLightTheme НЕ равно 1
{
	Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name ColorPrevalence равно 1
	{
		"Scripts\2. UI\27. Show accent color on Start, taskbar, and action center.ps1" -Off
	}
}

# Отображать цвет элементов в заголовках окон и границ окон
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\DWM -Name ColorPrevalence НЕ равно 1
{
	"Scripts\2. UI\28. Show accent color on the title bars and window borders.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\DWM -Name ColorPrevalence равно 1
{
	"Scripts\2. UI\28. Show accent color on the title bars and window borders.ps1" -Off
}

# Не показывать уведомление "Установлено новое приложение"
# Тумблер находится слева
Если значение HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer -Name NoNewAppAlert НЕ равно 1
ИЛИ
отсутствует HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer -Name NoNewAppAlert
{
	"Scripts\2. UI\29. Do not show New App Installed notification.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer -Name NoNewAppAlert равно 1
{
	"Scripts\2. UI\29. Do not show New App Installed notification.ps1" -On
}

# Не показывать анимацию при первом входе в систему
# Тумблер находится слева
Если значение HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System -Name EnableFirstLogonAnimation НЕ равно 0
ИЛИ
отсутствует HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System -Name EnableFirstLogonAnimation
{
	"Scripts\2. UI\30. Do not show user first sign-in animation.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System -Name EnableFirstLogonAnimation) -eq 0)
{
	"Scripts\2. UI\30. Do not show user first sign-in animation.ps1" -On
}

# Отключить снижение качества при импорте фонового изображение рабочего стола в формате JPEG
# Тумблер находится слева
Если значение "HKCU:\Control Panel\Desktop" -Name JPEGImportQuality) -ne 100)
ИЛИ
отсутствует "HKCU:\Control Panel\Desktop" -Name JPEGImportQuality
{
	"Scripts\2. UI\31. Turn off JPEG desktop wallpaper import quality reduction.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение "HKCU:\Control Panel\Desktop" -Name JPEGImportQuality) -eq 100)
{
	"Scripts\2. UI\31. Turn off JPEG desktop wallpaper import quality reduction.ps1" -On
}

# Показывать уведомление, когда компьютеру требуется перезагрузка для завершения обновления
# Тумблер находится слева
Если значение HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings -Name RestartNotificationsAllowed2) -ne 100)
ИЛИ
отсутствует HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings -Name RestartNotificationsAllowed2
{
	"Scripts\2. UI\32. Show a notification when your PC requires a restart to finish updating.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings -Name RestartNotificationsAllowed2) -eq 100)
{
	"Scripts\2. UI\32. Show a notification when your PC requires a restart to finish updating.ps1" -Off
}

# Нe дoбaвлять "- яpлык" для coздaвaeмыx яpлыкoв
# Тумблер находится слева
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name link НЕ равно [byte[]](00, 00, 00, 00)
ИЛИ
отсутствует HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name link
{
	"Scripts\2. UI\33. Do not add the '- Shortcut' for created shortcuts.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name link равно [byte[]](00, 00, 00, 00)
{
	"Scripts\2. UI\33. Do not add the '- Shortcut' for created shortcuts.ps1" -On
}

# Использовать кнопку PRINT SCREEN, чтобы запустить функцию создания фрагмента экрана
# Тумблер находится слева
Если значение "HKCU:\Control Panel\Keyboard" -Name PrintScreenKeyForSnippingEnabled НЕ равно 1
ИЛИ
отсутствует "HKCU:\Control Panel\Keyboard" -Name PrintScreenKeyForSnippingEnabled
{
	"Scripts\2. UI\34. Use the PrtScn button to open screen snipping.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение "HKCU:\Control Panel\Keyboard" -Name PrintScreenKeyForSnippingEnabled равно 1
{
	"Scripts\2. UI\34. Use the PrtScn button to open screen snipping.ps1" -Off
}

# Автоматически изменять период активности для этого устройства на основе действий
# Тумблер находится слева
Если значение HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings -Name SmartActiveHoursState НЕ равно 1
ИЛИ
отсутствует HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings -Name SmartActiveHoursState
{
	"Scripts\2. UI\35. Automatically adjust active hours for me based on daily usage.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
Если значение HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings -Name SmartActiveHoursState равно 1
{
	"Scripts\2. UI\35. Automatically adjust active hours for me based on daily usage.ps1" -Off
}