﻿# Get tip, trick, and suggestions as you use Windows
# Получать советы, подсказки и рекомендации при использованию Windowss
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SubscribedContent-338389Enabled -PropertyType DWord -Value 1 -Force