﻿# Set the minimal operating system diagnostic data level
# Установить минимальный уровень отправляемых диагностических сведений
param
(
	[Parameter()]
	[switch]
	$Enterprise,

	[Parameter()]
	[switch]
	$NotEnterprise,

	[Parameter()]
	[switch]
	$On
)

if ($Enterprise.IsPresent)
{
	if ((Get-WindowsEdition -Online).Edition -eq "Enterprise" -or (Get-WindowsEdition -Online).Edition -eq "Education")
	{
		# "Security"
		# "Безопасность"
		New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection -Name AllowTelemetry -PropertyType DWord -Value 0 -Force
	}
}

if ($NotEnterprise.IsPresent)
{
	if ((Get-WindowsEdition -Online).Edition -ne "Enterprise" -or (Get-WindowsEdition -Online).Edition -ne "Education")
	{
		# "Basic"
		# "Базовый"
		New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection -Name AllowTelemetry -PropertyType DWord -Value 1 -Force
	}
}

if ($On)
{
	# By default
	# По умолчанию
	New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection -Name AllowTelemetry -PropertyType DWord -Value 3 -Force
}