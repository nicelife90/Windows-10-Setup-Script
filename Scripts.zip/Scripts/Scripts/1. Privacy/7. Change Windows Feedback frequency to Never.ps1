﻿# Change Windows Feedback frequency to "Never"
# Изменить частоту формирования отзывов на "Никогда"
param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

if ($Off.IsPresent)
{
	if (-not (Test-Path -Path HKCU:\Software\Microsoft\Siuf\Rules))
	{
		New-Item -Path HKCU:\Software\Microsoft\Siuf\Rules -Force
	}
	New-ItemProperty -Path HKCU:\Software\Microsoft\Siuf\Rules -Name NumberOfSIUFInPeriod -PropertyType DWord -Value 0 -Force
}

if ($On.IsPresent)
{
	Remove-Item -Path HKCU:\Software\Microsoft\Siuf\Rules -Force
}