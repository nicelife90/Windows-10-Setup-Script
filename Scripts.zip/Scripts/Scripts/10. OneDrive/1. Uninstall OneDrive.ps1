﻿# Uninstall OneDrive
# Удалить OneDrive
[string] $UninstallString = Get-Package -Name "Microsoft OneDrive" -ErrorAction Ignore | ForEach-Object -Process {$_.Meta.Attributes["UninstallString"]}
if ($UninstallString)
{
	if ($RU)
	{
		Write-Verbose -Message "Удаление OneDrive" -Verbose
	}
	else
	{
		Write-Verbose -Message "Uninstalling OneDrive" -Verbose
	}
	Stop-Process -Name OneDrive -Force
	Stop-Process -Name FileCoAuth -ErrorAction Ignore -Force
	# Save all opened folders in order to restore them after File Explorer restarting
	# Сохранить все открытые папки, чтобы восстановить их после перезапуска проводника
	Clear-Variable -Name OpenedFolders -Force -ErrorAction Ignore
	$OpenedFolders = {(New-Object -ComObject Shell.Application).Windows() | ForEach-Object -Process {$_.Document.Folder.Self.Path}}.Invoke()
	# Getting link to the OneDriveSetup.exe and its' argument(s)
	# Получаем ссылку на OneDriveSetup.exe и его аргумент(ы)
	[string[]] $OneDriveSetup = ($UninstallString -Replace("\s*/",",/")).Trim().Split(",")
	if ($OneDriveSetup.Count -eq 2)
	{
		Start-Process -FilePath $OneDriveSetup[0] -ArgumentList $OneDriveSetup[1..1] -Wait
	}
	else
	{
		Start-Process -FilePath $OneDriveSetup[0] -ArgumentList $OneDriveSetup[1..2] -Wait
	}
	Stop-Process -Name explorer -Force
	# Restoring closed folders
	# Восстановляем закрытые папки
	foreach ($OpenedFolder in $OpenedFolders)
	{
		if (Test-Path -Path $OpenedFolder)
		{
			Invoke-Item -Path $OpenedFolder
		}
	}
	# Getting the OneDrive user folder path
	# Получаем путь до папки пользователя OneDrive
	$OneDriveUserFolder = Get-ItemPropertyValue -Path HKCU:\Environment -Name OneDrive
	if ((Get-ChildItem -Path $OneDriveUserFolder | Measure-Object).Count -eq 0)
	{
		Remove-Item -Path $OneDriveUserFolder -Recurse -Force
	}
	else
	{
		if ($RU)
		{
			Write-Error -Message "Папка $OneDriveUserFolder не пуста. Удалите ее вручную" -ErrorAction SilentlyContinue
		}
		else
		{
			Write-Error -Message "$OneDriveUserFolder folder is not empty. Delete it manually" -ErrorAction SilentlyContinue
		}
		Invoke-Item -Path $OneDriveUserFolder
	}
	Remove-ItemProperty -Path HKCU:\Environment -Name OneDrive, OneDriveConsumer -Force -ErrorAction Ignore
	Remove-Item -Path HKCU:\Software\Microsoft\OneDrive -Recurse -Force -ErrorAction Ignore
	Remove-Item -Path HKLM:\SOFTWARE\WOW6432Node\Microsoft\OneDrive -Recurse -Force -ErrorAction Ignore
	Remove-Item -Path "$env:ProgramData\Microsoft OneDrive" -Recurse -Force -ErrorAction Ignore
	Remove-Item -Path $env:SystemDrive\OneDriveTemp -Recurse -Force -ErrorAction Ignore
	Unregister-ScheduledTask -TaskName *OneDrive* -Confirm:$false
	# Getting the OneDrive folder path
	# Получаем путь до папки OneDrive
	$OneDriveFolder = Split-Path -Path (Split-Path -Path $OneDriveSetup[0] -Parent)
	# Waiting for the FileSyncShell64.dll to be unloaded, using System.IO.File class
	# Ожидаем, пока FileSyncShell64.dll выгрузится, используя класс System.IO.File
	$FileSyncShell64dllFolder = Get-ChildItem -Path "$OneDriveFolder\*\amd64\FileSyncShell64.dll" -Force
	foreach ($FileSyncShell64dll in $FileSyncShell64dllFolder)
	{
		do
		{
			try
			{
				$FileStream = [System.IO.File]::Open($FileSyncShell64dll.FullName,"Open","Write")
				$FileStream.Close()
				$FileStream.Dispose()
				$Locked = $false
			}
			catch [System.UnauthorizedAccessException]
			{
				$Locked = $true
			}
			catch [Exception]
			{
				Start-Sleep -Milliseconds 500
			}
		}
		while ($Locked)
	}
	Remove-Item -Path $OneDriveFolder -Recurse -Force
	Remove-Item -Path $env:LOCALAPPDATA\OneDrive -Recurse -Force -ErrorAction Ignore
	Remove-Item -Path $env:LOCALAPPDATA\Microsoft\OneDrive -Recurse -Force -ErrorAction Ignore
}