﻿# Set dark theme color for default Windows mode
# Установить режим Windows по умолчанию темный
param
(
	[Parameter()]
	[switch]
	$Light,

	[Parameter()]
	[switch]
	$Dark
)

if ($Light.IsPresent)
{
	New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name SystemUsesLightTheme -PropertyType DWord -Value 1 -Force
}

if ($Dark.IsPresent)
{
	New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name SystemUsesLightTheme -PropertyType DWord -Value 0 -Force
}