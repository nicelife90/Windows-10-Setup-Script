﻿# Set dark theme color for default Windows mode
# Установить режим Windows по умолчанию темный
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name SystemUsesLightTheme -PropertyType DWord -Value 0 -Force