﻿# Do not show Cortana button on taskbar
# Не показывать кнопку Кортаны на панели задач
param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

if ($Off.IsPresent)
{
	New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name ShowCortanaButton -PropertyType DWord -Value 0 -Force
}

if ($On.IsPresent)
{
	New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name ShowCortanaButton -PropertyType DWord -Value 1 -Force
}