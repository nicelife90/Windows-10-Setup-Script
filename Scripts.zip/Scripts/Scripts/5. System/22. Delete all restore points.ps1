﻿# Delete all restore points
# Удалить все точки восстановения
Get-CimInstance -ClassName Win32_ShadowCopy | Remove-CimInstance