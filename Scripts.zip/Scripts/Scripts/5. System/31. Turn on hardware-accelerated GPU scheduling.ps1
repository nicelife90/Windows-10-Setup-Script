﻿# Turn on hardware-accelerated GPU scheduling. Restart needed
# Включить планирование графического процессора с аппаратным ускорением. Необходима перезагрузка
if ((Get-CimInstance -ClassName CIM_VideoController | Where-Object -FilterScript {$_.AdapterDACType -ne "Internal"}))
{
	New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" -Name HwSchMode -PropertyType DWord -Value 2 -Force
}