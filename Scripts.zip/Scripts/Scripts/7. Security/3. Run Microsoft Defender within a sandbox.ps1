﻿# Run Microsoft Defender within a sandbox
# Запускать Microsoft Defender в песочнице
setx /M MP_FORCE_USE_SANDBOX 1