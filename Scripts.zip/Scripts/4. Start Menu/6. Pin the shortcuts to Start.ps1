﻿# Pin the shortcuts to Start
# Закрепить ярлыки на начальном экране
# Download syspin.exe to the "Downloads" folder
# Скачать syspin.exe в папку "Загрузки"
# http://www.technosys.net/products/utils/pintotaskbar
# SHA256: 6967E7A3C2251812DD6B3FA0265FB7B61AADC568F562A98C50C345908C6E827
if (Test-Connection -ComputerName google.com -Quiet)
{
	$DownloadsFolder = Get-ItemPropertyValue -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" -Name "{374DE290-123F-4565-9164-39C4925E467B}"
	[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
	$param = @{
		Uri = "https://github.com/farag2/Windows-10-Setup-Script/raw/master/Start%20menu%20pinning/syspin.exe"
		OutFile = "$DownloadsFolder\syspin.exe"
		Verbose = [switch]::Present
	}
	Invoke-WebRequest @param
}
else
{
	if ($RU)
	{
		Write-Warning "Отсутствует интернет-соединение" -ErrorAction SilentlyContinue
	}
	else
	{
		Write-Warning "No Internet connection" -ErrorAction SilentlyContinue
	}
}
Add-Type -AssemblyName System.Windows.Forms
$OpenFileDialog = New-Object -TypeName System.Windows.Forms.OpenFileDialog
$OpenFileDialog.InitialDirectory = $DownloadsFolder
if ($RU)
{
	$OpenFileDialog.Filter = "*.exe|*.exe|Все файлы (*.*)|*.*"
}
else
{
	$OpenFileDialog.Filter = "*.exe|*.exe|All Files (*.*)|*.*"
}
# Focus on open file dialog
# Перевести фокус на диалог открытия файла
$tmp = New-Object System.Windows.Forms.Form -Property @{TopMost = $true}
$OpenFileDialog.ShowDialog($tmp)
if ($OpenFileDialog.FileName)
{
	# Pin "Control Panel" to Start
	# Закрепить "Панель управления" на начальном экране
	$Items = (New-Object -ComObject Shell.Application).NameSpace("shell:::{4234d49b-0245-4df3-b780-3893943456e1}").Items()
	$ControlPanelLocalizedName = ($Items | Where-Object -FilterScript {$_.Path -eq "Microsoft.Windows.ControlPanel"}).Name
	# Check whether the Control Panel shortcut was ever pinned
	# Проверка: закреплялся ли когда-нибудь ярлык панели управления
	if (Test-Path -Path "$env:APPDATA\Microsoft\Windows\Start menu\Programs\$ControlPanelLocalizedName.lnk")
	{
		$Arguments = @"
			"$env:APPDATA\Microsoft\Windows\Start menu\Programs\$ControlPanelLocalizedName.lnk" "51201"
"@
		Start-Process -FilePath $OpenFileDialog.FileName -WindowStyle Hidden -ArgumentList $Arguments -Wait
	}
	else
	{
		# The "Pin" verb is not available on the control.exe file so the shortcut has to be created
		# Глагол "Закрепить на начальном экране" недоступен для control.exe, поэтому необходимо создать ярлык
		$shell = New-Object -ComObject Wscript.Shell
		$shortcut = $shell.CreateShortcut("$env:SystemRoot\System32\$ControlPanelLocalizedName.lnk")
		$shortcut.TargetPath = "$env:SystemRoot\System32\control.exe"
		$shortcut.Save()
		$Arguments = @"
			"$env:SystemRoot\System32\$ControlPanelLocalizedName.lnk" "51201"
"@
		Start-Process -FilePath $OpenFileDialog.FileName -WindowStyle Hidden -ArgumentList $Arguments -Wait
		Remove-Item -Path "$env:SystemRoot\System32\$ControlPanelLocalizedName.lnk" -Force
	}
	# Pin "Devices and Printers" to Start
	# Create old style shortcut for the "Devices and Printers" in the Start menu
	# Закрепить "Устройства и принтеры" на начальном экране
	# Создать ярлык старого формата для "Устройства и принтеры" в меню "Пуск"
	$DevicesAndPrintersLocalizedName = (Get-ControlPanelItem | Where-Object -FilterScript {$_.CanonicalName -eq "Microsoft.DevicesAndPrinters"}).Name
	$shell = New-Object -ComObject Wscript.Shell
	$shortcut = $shell.CreateShortcut("$env:APPDATA\Microsoft\Windows\Start menu\Programs\System Tools\$DevicesAndPrintersLocalizedName.lnk")
	$shortcut.TargetPath = "control"
	$shortcut.Arguments = "printers"
	$shortCut.IconLocation = "$env:SystemRoot\system32\DeviceCenter.dll"
	$shortcut.Save()
	# Pause for 3 sec, unless the "Devices and Printers" shortcut won't displayed in the Start menu
	# Пауза на 3 с, иначе ярлык "Устройства и принтеры" не будет отображаться в меню "Пуск"
	Start-Sleep -Seconds 3
	$Arguments = @"
		"$env:APPDATA\Microsoft\Windows\Start menu\Programs\System Tools\$DevicesAndPrintersLocalizedName.lnk" "51201"
"@
	Start-Process -FilePath $OpenFileDialog.FileName -WindowStyle Hidden -ArgumentList $Arguments -Wait
	# Pin "Command Prompt" to Start
	# Закрепить "Командную строку" на начальном экране
	$Arguments = @"
		"$env:APPDATA\Microsoft\Windows\Start menu\Programs\System Tools\Command Prompt.lnk" "51201"
"@
	Start-Process -FilePath $OpenFileDialog.FileName -WindowStyle Hidden -ArgumentList $Arguments -Wait
}
# Delete downloaded syspin.exe
# Удалить скачанный syspin.exe
Remove-Item -Path "$DownloadsFolder\syspin.exe" -Force
# Restart the Start menu
# Перезапустить меню "Пуск"
Stop-Process -Name StartMenuExperienceHost -Force