﻿# Set light theme color for default Windows mode
# Установить режим Windows по умолчанию светлый
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name SystemUsesLightTheme -PropertyType DWord -Value 1 -Force