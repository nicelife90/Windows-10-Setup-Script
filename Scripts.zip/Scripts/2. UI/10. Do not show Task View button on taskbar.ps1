﻿# Do not show sync provider notification within File Explorer
# Не показывать уведомления поставщика синхронизации в проводнике
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name ShowSyncProviderNotifications -PropertyType DWord -Value 0 -Force