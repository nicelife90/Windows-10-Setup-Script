﻿# Set light theme color for default app mode
# Установить режим приложений по умолчанию светлый
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name AppsUseLightTheme -PropertyType DWord -Value 1 -Force