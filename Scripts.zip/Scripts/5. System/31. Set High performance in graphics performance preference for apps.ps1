﻿# Set "High performance" in graphics performance preference for apps
# Установить параметры производительности графики для отдельных приложений на "Высокая производительность"
Start-Process -FilePath ms-settings:display-advancedgraphics