﻿# Remove Windows capabilities
# Удалить дополнительные компоненты Windows
$Capabilities = @(
	# Steps Recorder
	# Средство записи действий
	"App.StepsRecorder*"
	# Microsoft Quick Assist
	# Быстрая поддержка (Майкрософт)
	"App.Support.QuickAssist*"
	# Windows Media Player
	# Проигрыватель Windows Media
	"Media.WindowsMediaPlayer*"
	# Microsoft Paint
	"Microsoft.Windows.MSPaint*"
	# Notepad
	# Блокнот
	"Microsoft.Windows.Notepad*"
	# WordPad
	"Microsoft.Windows.WordPad*"
	# Integrated faxing and scanning application for Windows
	# Факсы и сканирование Windows
	"Print.Fax.Scan*"
)
# If device is not a laptop
# Если устройство не является ноутбуком
if ((Get-CimInstance -ClassName Win32_ComputerSystem).PCSystemType -ne 2)
{
	# Windows Hello Face
	# Распознавание лиц Windows Hello
	$Capabilities += "Hello.Face*"
}
$OFS = "|"
Get-WindowsCapability -Online | Where-Object -FilterScript {$_.Name -cmatch $Capabilities} | Remove-WindowsCapability -Online
$OFS = " "