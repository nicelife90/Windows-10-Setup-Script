﻿# Отобразить "Этот компьютер" на рабочем столе
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel -Name "{20D04FE0-3AEA-1069-A2D8-08002B30309D}") -ne 0) -or (-not (Get-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel -Name "{20D04FE0-3AEA-1069-A2D8-08002B30309D}")))
{
	"Scripts\2. UI\1. Show This PC on Desktop.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel -Name "{20D04FE0-3AEA-1069-A2D8-08002B30309D}") -eq 1)
{
	"Scripts\2. UI\1. Show This PC on Desktop.ps1" -Off
}

# Не использовать флажки для выбора элементов
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name AutoCheckSelect) -ne 0)
{
	"Scripts\2. UI\2. Do not use check boxes to select items.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name AutoCheckSelect) -eq 0)
{
	"Scripts\2. UI\2. Do not use check boxes to select items.ps1" -On
}

# Показывать скрытые файлы, папки и диски
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name Hidden) -ne 1)
{
	"Scripts\2. UI\3. Show hidden files, folders, and drives.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name Hidden) -eq 1)
{
	"Scripts\2. UI\3. Show hidden files, folders, and drives.ps1" -Off
}

# Показывать расширения для зарегистрированных типов файлов
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name HideFileExt) -ne 0)
{
	"Scripts\2. UI\4. Show file name extensions.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name HideFileExt) -eq 0)
{
	"Scripts\2. UI\4. Show file name extensions.ps1" -Off
}

# Не скрывать конфликт слияния папок
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name HideMergeConflicts) -ne 0) -or (-not (Get-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name HideMergeConflicts)))
{
	"Scripts\Scripts\2. UI\5. 5. Do not hide folder merge conflicts.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name HideMergeConflicts) -eq 0)
{
	"Scripts\Scripts\2. UI\5. Show folder merge conflicts.ps1" -Off
}

# Открывать проводник для: "Этот компьютер"
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name LaunchTo) -ne 1) -or (-not (Get-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name LaunchTo)))
{
	"Scripts\2. UI\6. Open File Explorer to This PC.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name LaunchTo) -eq 1)
{
	"Scripts\2. UI\6. Open File Explorer to This PC.ps1" -Off
}

# Не отображать все папки в области навигации
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name NavPaneShowAllFolders) -ne 0) -or (-not (Get-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name NavPaneShowAllFolders)))
{
	"Scripts\2. UI\7. Do not show all folders in the navigation pane.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name NavPaneShowAllFolders) -eq 0)
{
	"Scripts\2. UI\7. Do not show all folders in the navigation pane.ps1" -On
}

# Не показывать кнопку Кортаны на панели задач
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name ShowCortanaButton) -ne 0)
{
	"Scripts\2. UI\8. Do not show Cortana button on taskbar.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name ShowCortanaButton) -eq 0)
{
	"Scripts\2. UI\8. Do not show Cortana button on taskbar.ps1" -On
}

# Не показывать уведомления поставщика синхронизации в проводнике
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name ShowSyncProviderNotifications) -ne 0) -or (-not (Get-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name ShowSyncProviderNotifications)))
{
	"Scripts\2. UI\9. Do not show sync provider notification within File Explorer.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name ShowSyncProviderNotifications) -eq 0)
{
	"Scripts\2. UI\9. Do not show sync provider notification within File Explorer.ps1" -On
}

# Не показывать кнопку Просмотра задач
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name ShowTaskViewButton) -ne 0) -or (-not (Get-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name ShowTaskViewButton)))
{
	"Scripts\2. UI\10. Do not show Task View button on taskbar.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name ShowTaskViewButton) -eq 0)
{
	"Scripts\2. UI\10. Do not show Task View button on taskbar.ps1" -On
}

# Не показывать панель "Люди" на панели задач
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People -Name PeopleBand) -ne 0) -or (-not (Get-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People -Name PeopleBand)))
{
	"Scripts\2. UI\11. Do not show People button on the taskbar.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People -Name PeopleBand) -eq 0)
{
	"Scripts\2. UI\11. Do not show People button on the taskbar.ps1" -On
}

# Отображать секунды в системных часах на панели задач
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People -Name ShowSecondsInSystemClock) -ne 1) -or (-not (Get-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People -Name ShowSecondsInSystemClock)))
{
	"Scripts\2. UI\12. Show seconds on taskbar clock.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People -Name ShowSecondsInSystemClock) -eq 1)
{
	"Scripts\2. UI\12. Show seconds on taskbar clock.ps1" -Off
}

# Увеличить прозрачность панели задач
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name UseOLEDTaskbarTransparency) -ne 1) -or (-not (Get-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name UseOLEDTaskbarTransparency)))
{
	"Scripts\2. UI\13. Increase taskbar transparency.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name UseOLEDTaskbarTransparency) -eq 1)
{
	"Scripts\2. UI\13. Increase taskbar transparency.ps1" -Off
}

# Не показывать при прикреплении окна, что можно прикрепить рядом с ним
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name SnapAssist) -ne 1) -or (-not (Get-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name SnapAssist)))
{
	"Scripts\2. UI\14. Do not show when snapping a window, what can be attached next to it.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name SnapAssist) -eq 1)
{
	"Scripts\2. UI\14. Do not show when snapping a window, what can be attached next to it.ps1" -On
}

# Развернуть диалог переноса файлов
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\OperationStatusManager -Name EnthusiastMode) -ne 1) -or (-not (Get-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\OperationStatusManager -Name EnthusiastMode)))
{
	"Scripts\2. UI\15. Show more details in file transfer dialog.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\OperationStatusManager -Name EnthusiastMode) -eq 1)
{
	"Scripts\2. UI\15. Show more details in file transfer dialog.ps1" -Off
}

# Отображать ленту проводника в развернутом виде
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Ribbon -Name MinimizedStateTabletModeOff) -ne 1) -or (-not (Get-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Ribbon -Name MinimizedStateTabletModeOff)))
{
	"Scripts\2. UI\16. Show the Ribbon expanded in File Explorer.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Ribbon -Name MinimizedStateTabletModeOff) -eq 1)
{
	"Scripts\2. UI\16. Show the Ribbon expanded in File Explorer.ps1" -On
}

# Запрашивать подтверждение на удаление файлов в корзину
# Тумблер находится слева
$ShellState = Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name ShellState
if ($ShellState[4] -eq 51)
{
	"Scripts\2. UI\17. Display recycle bin files delete confirmation.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
$ShellState = Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name ShellState
if ($ShellState[4] -ne 51)
{
	"Scripts\2. UI\17. Display recycle bin files delete confirmation.ps1" -Off
}

# Скрыть папку "Объемные объекты" из "Этот компьютер" и из панели быстрого доступа
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\FolderDescriptions\{31C0DD25-9439-4F12-BF41-7FF4EDA38722}\PropertyBag" -Name ThisPCPolicy) -ne "Hide") -or (-not (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\FolderDescriptions\{31C0DD25-9439-4F12-BF41-7FF4EDA38722}\PropertyBag" -Name ThisPCPolicy)))
{
	"Scripts\2. UI\18. Hide 3D Objects folder from This PC and from Quick Access Toolbar.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\FolderDescriptions\{31C0DD25-9439-4F12-BF41-7FF4EDA38722}\PropertyBag" -Name ThisPCPolicy) -eq "Hide")
{
	"Scripts\2. UI\18. Hide 3D Objects folder from This PC and from Quick Access Toolbar.ps1" -On
}

# Не показывать недавно используемые папки на панели быстрого доступа
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name ShowFrequent) -ne 0) -or (-not (Get-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name ShowFrequent)))
{
	"Scripts\2. UI\19. Do not show Frequent folders in Quick access.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name ShowFrequent) -eq 0)
{
	"Scripts\2. UI\19. Do not show Frequent folders in Quick access.ps1" -On
}

# Не показывать недавно использовавшиеся файлы на панели быстрого доступа
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name ShowRecent) -ne 0) -or (-not (Get-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name ShowRecent)))
{
	"Scripts\2. UI\20. Do not show Recent files in Quick access.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name ShowRecent) -eq 0)
{
	"Scripts\2. UI\20. Do not show Recent files in Quick access.ps1" -On
}

# Скрыть поле или значок поиска на панели задач
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Search -Name SearchboxTaskbarMode) -ne 0) -or (-not (Get-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Search -Name SearchboxTaskbarMode)))
{
	"Scripts\2. UI\21. Hide search box or search icon on taskbar.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Search -Name SearchboxTaskbarMode) -eq 0)
{
	"Scripts\2. UI\21. Hide search box or search icon on taskbar.ps1" -On
}

# Не показывать кнопку Windows Ink Workspace на панели задач
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\PenWorkspace -Name PenWorkspaceButtonDesiredVisibility) -ne 0) -or (-not (Get-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\PenWorkspace -Name PenWorkspaceButtonDesiredVisibility)))
{
	"Scripts\2. UI\22. Do not show Windows Ink Workspace button in taskbar.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\PenWorkspace -Name PenWorkspaceButtonDesiredVisibility) -eq 0)
{
	"Scripts\2. UI\22. Do not show Windows Ink Workspace button in taskbar.ps1" -On
}

# Всегда отображать все значки в области уведомлений
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name EnableAutoTray) -ne 0) -or (-not (Get-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name EnableAutoTray)))
{
	"Scripts\2. UI\23. Always show all icons in the notification area.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name EnableAutoTray) -eq 0)
{
	"Scripts\2. UI\23. Always show all icons in the notification area.ps1" -On
}

# Установить крупные значки в Панели управления
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel -Name AllItemsIconView) -ne 0) -or (-not (Get-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel -Name AllItemsIconView)))
{
	$AllItemsIconView = $false
}
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel -Name StartupPage) -ne 1) -or (-not (Get-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel -Name StartupPage)))
{
	$StartupPage = $false
}
if ((-not $AllItemsIconView) -and (-not $StartupPage))
{
	"Scripts\2. UI\24. Set the large icons in the Control Panel.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel -Name AllItemsIconView) -eq 0))
{
	$AllItemsIconView = $true
}
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel -Name StartupPage) -eq 1)
{
	$StartupPage = $true
}
if ($AllItemsIconView -and $StartupPage)
{
	"Scripts\2. UI\24. Set the large icons in the Control Panel.ps1" -Off
}

# Установить режим Windows по умолчанию темный
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name SystemUsesLightTheme) -ne 1)
{
	"Scripts\2. UI\25. Set theme color for default Windows mode.ps1" -Light
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name SystemUsesLightTheme) -eq 1)
{
	"Scripts\2. UI\25. Set theme color for default Windows mode.ps1" -Dark
}

# Установить режим приложений по умолчанию светлый
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name AppsUseLightTheme) -ne 1)
{
	"Scripts\2. UI\26. Set theme color for default app mode.ps1" -Light
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name AppsUseLightTheme) -eq 1)
{
	"Scripts\2. UI\26. Set theme color for default app mode.ps1" -Dark
}

# Отображать цвет элементов в меню "Пуск", на панели задач и в центре уведомлений
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name SystemUsesLightTheme) -ne 1)
{
	if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name ColorPrevalence) -ne 1)
	{
		"Scripts\2. UI\27. Show accent color on Start, taskbar, and action center.ps1" -On
	}
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name SystemUsesLightTheme) -ne 1)
{
	if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name ColorPrevalence) -eq 1)
	{
		"Scripts\2. UI\27. Show accent color on Start, taskbar, and action center.ps1" -Off
	}
}

# Отображать цвет элементов в заголовках окон и границ окон
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\DWM -Name ColorPrevalence) -ne 1)
{
	"Scripts\2. UI\28. Show accent color on the title bars and window borders.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\DWM -Name ColorPrevalence) -eq 1)
{
	"Scripts\2. UI\28. Show accent color on the title bars and window borders.ps1" -Off
}

# Не показывать уведомление "Установлено новое приложение"
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer -Name NoNewAppAlert) -ne 1) -or (-not (Get-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer -Name NoNewAppAlert)))
{
	"Scripts\2. UI\29. Do not show New App Installed notification.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer -Name NoNewAppAlert) -eq 1)
{
	"Scripts\2. UI\29. Do not show New App Installed notification.ps1" -On
}

# Не показывать анимацию при первом входе в систему
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System -Name EnableFirstLogonAnimation) -ne 0) -or (-not (Get-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System -Name EnableFirstLogonAnimation)))
{
	"Scripts\2. UI\30. Do not show user first sign-in animation.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System -Name EnableFirstLogonAnimation) -eq 0)
{
	"Scripts\2. UI\30. Do not show user first sign-in animation.ps1" -On
}

# Отключить снижение качества при импорте фонового изображение рабочего стола в формате JPEG
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path "HKCU:\Control Panel\Desktop" -Name JPEGImportQuality) -ne 100) -or (-not (Get-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name JPEGImportQuality)))
{
	"Scripts\2. UI\31. Turn off JPEG desktop wallpaper import quality reduction.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path "HKCU:\Control Panel\Desktop" -Name JPEGImportQuality) -eq 100)
{
	"Scripts\2. UI\31. Turn off JPEG desktop wallpaper import quality reduction.ps1" -On
}

# Показывать уведомление, когда компьютеру требуется перезагрузка для завершения обновления
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings -Name RestartNotificationsAllowed2) -ne 100) -or (-not (Get-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings -Name RestartNotificationsAllowed2)))
{
	"Scripts\2. UI\32. Show a notification when your PC requires a restart to finish updating.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings -Name RestartNotificationsAllowed2) -eq 100)
{
	"Scripts\2. UI\32. Show a notification when your PC requires a restart to finish updating.ps1" -Off
}

# Нe дoбaвлять "- яpлык" для coздaвaeмыx яpлыкoв
# Тумблер находится слева
if ((((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name link) -join " ") -ne ([byte[]](00, 00, 00, 00) -join " ")) -or (-not (Get-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name link)))
{
	"Scripts\2. UI\33. Do not add the '- Shortcut' for created shortcuts.ps1" -Off
}
# Вернуть по умолчанию
# Тумблер находится справа
if (((Get-ItemPropertyValue -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name link) -join " ") -ne ([byte[]](00, 00, 00, 00) -join " "))
{
	"Scripts\2. UI\33. Do not add the '- Shortcut' for created shortcuts.ps1" -On
}

# Использовать кнопку PRINT SCREEN, чтобы запустить функцию создания фрагмента экрана
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path "HKCU:\Control Panel\Keyboard" -Name PrintScreenKeyForSnippingEnabled) -ne 1) -or (-not (Get-ItemProperty -Path "HKCU:\Control Panel\Keyboard" -Name PrintScreenKeyForSnippingEnabled)))
{
	"Scripts\2. UI\34. Use the PrtScn button to open screen snipping.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path "HKCU:\Control Panel\Keyboard" -Name PrintScreenKeyForSnippingEnabled) -eq 1)
{
	"Scripts\2. UI\34. Use the PrtScn button to open screen snipping.ps1" -Off
}

# Автоматически изменять период активности для этого устройства на основе действий
# Тумблер находится слева
if ((Get-ItemPropertyValue -Path HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings -Name SmartActiveHoursState) -ne 1) -or (-not (Get-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings -Name SmartActiveHoursState)))
{
	"Scripts\2. UI\35. Automatically adjust active hours for me based on daily usage.ps1" -On
}
# Вернуть по умолчанию
# Тумблер находится справа
if ((Get-ItemPropertyValue -Path HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings -Name SmartActiveHoursState) -eq 1)
{
	"Scripts\2. UI\35. Automatically adjust active hours for me based on daily usage.ps1" -Off
}