﻿# Turn on detection for potentially unwanted applications
# Включить обнаружение потенциально нежелательных приложений
Set-MpPreference -PUAProtection Enabled