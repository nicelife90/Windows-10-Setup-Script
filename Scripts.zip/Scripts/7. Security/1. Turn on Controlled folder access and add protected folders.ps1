﻿# Turn on Controlled folder access and add protected folders
# Включить контролируемый доступ к папкам и добавить защищенные папки
Start-Process -FilePath windowsdefender: