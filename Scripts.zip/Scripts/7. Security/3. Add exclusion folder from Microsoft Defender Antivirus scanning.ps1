﻿# Add exclusion folder from Microsoft Defender Antivirus scanning
# Добавить папку в список исключений сканирования Microsoft Defender
Start-Process -FilePath windowsdefender: