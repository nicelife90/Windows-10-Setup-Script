﻿# Turn on events auditing generated when a process is created or starts
# Включить аудит событий, возникающих при создании или запуске процесса
if ($RU)
{
	auditpol /set /subcategory:"Создание процесса" /success:enable /failure:enable
}
else
{
	auditpol /set /subcategory:"Process Creation" /success:enable /failure:enable
}