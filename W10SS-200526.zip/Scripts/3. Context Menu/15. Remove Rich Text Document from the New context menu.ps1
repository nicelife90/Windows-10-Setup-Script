﻿# Remove "Rich Text Document" from the "New" context menu
# Удалить пункт "Документ в формате RTF" из контекстного меню "Создать"
if ((Get-WindowsCapability -Online -Name "Microsoft.Windows.WordPad*").State -eq "Installed")
{
	Remove-Item -Path Registry::HKEY_CLASSES_ROOT\.rtf\ShellNew -Force -ErrorAction Ignore
}