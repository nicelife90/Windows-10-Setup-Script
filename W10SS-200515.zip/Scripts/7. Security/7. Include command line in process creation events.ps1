﻿# Include command line in process creation events
# Включать командную строку в событиях создания процесса
$ProcessCreation = auditpol /get /subcategory:"{0CCE922B-69AE-11D9-BED3-505054503030}" /r | ConvertFrom-Csv | Select-Object "Inclusion Setting"
if ($ProcessCreation."Inclusion Setting" -ne "No Auditing")
{
	New-ItemProperty -Path HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\Audit -Name ProcessCreationIncludeCmdLine_Enabled -PropertyType DWord -Value 1 -Force
}