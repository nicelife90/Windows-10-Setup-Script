﻿# Always show all icons in the notification area
#! Do not modify this string
# Всегда отображать все значки в области уведомлений
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name EnableAutoTray -PropertyType DWord -Value 0 -Force