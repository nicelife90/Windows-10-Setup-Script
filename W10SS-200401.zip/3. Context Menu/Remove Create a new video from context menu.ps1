﻿# Remove "Create a new video" from context menu
#! Do not modify this string
# Удалить пункт "Создать новое видео" из контекстного меню
#! Не изменяйте эту строку
New-ItemProperty -Path Registry::HKEY_CLASSES_ROOT\AppX43hnxtbyyps62jhe9sqpdzxn1790zetc\Shell\ShellCreateVideo -Name ProgrammaticAccessOnly -PropertyType String -Value "" -Force