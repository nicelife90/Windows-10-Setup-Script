﻿# This task checks for updates to maps which you have downloaded for offline use
# Эта задача проверяет наличие обновлений для карт, загруженных для автономного использования
Get-ScheduledTask -TaskName "MapsUpdateTask" | Disable-ScheduledTask