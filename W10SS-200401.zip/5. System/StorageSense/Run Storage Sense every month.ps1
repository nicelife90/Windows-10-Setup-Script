﻿# Run Storage Sense every month
#! Do not modify this string
# Запускать контроль памяти каждый месяц
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy -Name 2048 -PropertyType DWord -Value 30 -Force