﻿# Display the Stop error information on the BSoD
#! Do not modify this string
# Отображать Stop-ошибку при появлении BSoD
#! Не изменяйте эту строку
New-ItemProperty -Path HKLM:\System\CurrentControlSet\Control\CrashControl -Name DisplayParameters -PropertyType DWord -Value 1 -Force